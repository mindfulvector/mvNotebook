﻿
Welcome to the nnsNotebook program! 

Each Notebook tab above is a directory under Documents\nnsNotebook. Each one can contain unlimited pages.

It currently can switch between 10 notebooks, auto saves every 5 minutes as well as on tab change and on close. Rich text formatting is fairly robust, and accessed by selecting a piece of text then using the popup.

Additional features will be added soon, such as file exporting, syncronization, and more.

<img src="nnsNotebook-Repository-OG-Hero1.png" />
